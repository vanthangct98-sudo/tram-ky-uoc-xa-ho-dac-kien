# Trạm Ký Ức — Đoàn xã Hồ Đắc Kiện

Website tĩnh tiếng Việt đã được tùy chỉnh cho **ĐOÀN XÃ HỒ ĐẮC KIỆN**.

## Nội dung đã hoàn thiện
- Cập nhật đơn vị thực hiện ở phần thông tin công trình và chân trang.
- Bổ sung danh sách **399 liệt sĩ** từ tệp `DS LIET SI.xlsx` do đơn vị cung cấp.
- Tìm kiếm không phân biệt dấu theo họ tên, số thứ tự, mã số hồ sơ và ký hiệu.
- Bảng danh sách có phân trang 20 hồ sơ/trang, phù hợp trên điện thoại và máy tính.
- Giữ lại các phần tưởng niệm, hồ sơ ký ức mẫu và sổ lưu bút của website ban đầu.

## Cách xem
Mở `index.html` bằng trình duyệt. Website chạy cục bộ, không cần cài đặt.

## Lưu ý trước khi công bố chính thức
- Danh sách được chuyển từ bảng Excel nguồn; cần rà soát lại chính tả họ tên, mã hồ sơ và quyền công khai dữ liệu.
- Sổ lưu bút và bộ đếm tưởng niệm hiện lưu trên trình duyệt của từng thiết bị, chưa đồng bộ giữa người dùng.
- Trường email liên hệ đang để lời nhắc bổ sung; hãy cập nhật email/số điện thoại chính thức trước khi đưa website lên mạng.
- Đây là website tĩnh; chưa có trang quản trị hoặc cơ sở dữ liệu dùng chung.


## Bổ sung nhạc “Chiêu hồn tử sĩ”
- Đặt tệp MP3 mà bạn có quyền sử dụng tại `music/chieu-hon-tu-si.mp3`.
- Người xem bấm nút **Bật nhạc Chiêu hồn tử sĩ** để phát; nhạc lặp lại đến khi tắt.
- Chưa kèm tệp nhạc vì bạn chưa cung cấp bản ghi âm có thể sử dụng hợp pháp.

## Đưa lên Vercel
1. Giải nén thư mục dự án và bổ sung tệp MP3 như hướng dẫn trên.
2. Đưa toàn bộ thư mục `tram-ky-uc-ho-dac-kien` lên một repository GitHub.
3. Đăng nhập Vercel, chọn **Add New → Project**, kết nối repository.
4. Vì đây là website HTML tĩnh, để Framework Preset là **Other**, Build Command để trống và Output Directory đặt `.`.
5. Chọn **Deploy**. Vercel sẽ cung cấp URL `*.vercel.app`; có thể gắn tên miền riêng trong phần **Settings → Domains**.

Lưu ý: chưa thể triển khai trực tiếp từ phiên chat này vì chưa có quyền truy cập tài khoản Vercel/GitHub của bạn.
